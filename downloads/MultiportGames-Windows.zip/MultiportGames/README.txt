Multiport Games - Desktop App
==============================

This is a lightweight native Windows app (~650 KB) that opens
multiportgames.pages.dev in its own window using Microsoft Edge WebView2
-- the same rendering engine built into Windows 10/11 -- instead of
bundling a separate copy of a browser.

Requirements:
- Windows 10 or 11
- Microsoft Edge WebView2 Runtime (already preinstalled on Windows 11
  and on most updated Windows 10 machines; if missing, Windows will
  offer to install it automatically, or you can get it free from
  Microsoft at https://developer.microsoft.com/microsoft-edge/webview2/)
- An internet connection, since it loads the live website

How to run:
1. Keep MultiportGames.exe and WebView2Loader.dll in the same folder.
2. Double-click MultiportGames.exe.
